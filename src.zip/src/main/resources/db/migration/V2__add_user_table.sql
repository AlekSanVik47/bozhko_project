INSERT INTO "user" (login, surname, name, phone, email, password, state_id, status_id)
VALUES ('login', 'surname', 'name', '775-705', 'emailtest@mail.ru', 'password', 2, 1);
