ALTER TABLE announcement ADD description VARCHAR(255);
ALTER TABLE announcement ADD price DOUBLE PRECISION;
ALTER TABLE announcement ADD image VARCHAR(255);
